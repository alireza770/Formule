﻿using Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using System.Timers;


namespace Controller
{
    public class Race
    {
        public Track Track { get; set; } 
        public List<lParticipant> Participants { get; set; } = new List<lParticipant> { };
        public event EventHandler<DriversChangedEventArgs> Driverschanged;
        public DateTime Starttime { get; set; }
        private Random _random = new Random(DateTime.Now.Millisecond);
        private Dictionary<Section, SectionData> _positions = new Dictionary<Section, SectionData>();
        private System.Timers.Timer timer;
        Dictionary<lParticipant, int> laps = new Dictionary<lParticipant, int>();
        public event RaceAfgelopenDel RaceAfgelopen;
        public delegate void RaceAfgelopenDel();

        public Race(Track track, List<lParticipant> participants)
        {
            Track = track;
            Participants = participants;
            DriversStartPlacement(track, participants);
            timer = new System.Timers.Timer();
            timer.Interval = 500;
            timer.Elapsed += OnTimedEvent;
            timer.AutoReset = true;


            RandomizeEquipment();
            
            
        }

        private void RecoverBreakEnquipment()
        {
            foreach (var participant in Participants)
            {
                if (participant.Equipment.isBroken == false)
                {
                    participant.Equipment.isBroken = BreakEnquipment();
                } else
                {
                    participant.Equipment.isBroken = !RecoverEnquipment();
                }
               
            }
        }

        private bool BreakEnquipment()
        {
            int breekgetal = 23;
            int randomgetal = _random.Next(1, 25);
            return breekgetal == randomgetal;
        }
        private bool RecoverEnquipment()
        {
            int breekgetal = 9;
            int randomgetal = _random.Next(1, 10);
            return breekgetal == randomgetal;
        }

        public void Start()
        {
            timer.Start();
        }
        private void OnTimedEvent(object? sender, ElapsedEventArgs e)
        {
            RecoverBreakEnquipment();
            DriversMovement(Track);
            
            Driverschanged?.Invoke(this, new DriversChangedEventArgs(Track));


        }


        public SectionData GetSectionData(Section section)
        {
            if (_positions.ContainsKey(section))
            {
                return _positions.GetValueOrDefault(section);
            }
           else
            {
                var sectiondata = new SectionData();
                _positions.Add(section, sectiondata);

                return sectiondata;
            }
            
        }


        public void RandomizeEquipment()
        {
            foreach (var participant in Participants)
            {
                participant.Equipment.Performance = _random.Next(5,10);
                participant.Equipment.Quality =_random.Next(5,10);
            }
        }

        public void DriversStartPlacement(Track track, List<lParticipant> participanten )
        {
            
            foreach (Section sectie in track.Sections)
            {
                
               if (sectie.SectionType == SectionTypes.StartGrid)
                {
                        GetSectionData(sectie).Left = participanten[0];
                        GetSectionData(sectie).Right = participanten[1];
                    
                }
                if (sectie.SectionType == SectionTypes.StartGrid3)
                {
                    GetSectionData(sectie).Left = participanten[2];
                    GetSectionData(sectie).Right = participanten[3];
                  
                }
                if (sectie.SectionType == SectionTypes.StartGrid2)
                {
                    GetSectionData(sectie).Left = participanten[4];
                    GetSectionData(sectie).Right = participanten[5];
                  
                }
            }
        }



        public void DriversMovement(Track track)
        {
            


            for (int i = 0; i < track.Sections.Count ; i++)
            {
                if (GetSectionData(track.Sections.ElementAt(i)).Left != null)
                {
                    LeftDriversMove(track.Sections.ElementAt(i));
                }
                if (GetSectionData(track.Sections.ElementAt(i)).Right != null)
                {
                    RightDriversMove(track.Sections.ElementAt(i));
                }
                if (track.Sections.Last() == track.Sections.ElementAt(i) && GetSectionData(track.Sections.ElementAt(i)).Left != null && GetSectionData(track.Sections.ElementAt(i)).DistanceLeft <= 0)
                {

                        GetSectionData(track.Sections.ElementAt(i)).Left = DriversFinishedLeft(GetSectionData(track.Sections.ElementAt(i)).Left);
                    if (Racefinished() && GetSectionData(track.Sections.ElementAt(i)).Left == null)
                    {
                        clear();
                        if (RaceAfgelopen != null)
                        {
                            
                            RaceAfgelopen();
                            
                        }
                        
                        
                        
                    }
                }
                if (track.Sections.Last() == track.Sections.ElementAt(i) && GetSectionData(track.Sections.ElementAt(i)).Right != null && GetSectionData(track.Sections.ElementAt(i)).DistanceRight <= 0)
                {

                    GetSectionData(track.Sections.ElementAt(i)).Right = DriversFinishedLeft(GetSectionData(track.Sections.ElementAt(i)).Right);
                    if (Racefinished() && GetSectionData(track.Sections.ElementAt(i)).Right == null)
                    {
                        clear();
                        if (RaceAfgelopen != null)
                        {
                            
                            RaceAfgelopen();
                        }
                        

                    }
                }


            }
            

        }
        public bool Racefinished()
        {
            int totaal = 0;
            foreach (var i in laps )
            {
                totaal = totaal + i.Value;
            }
            if (totaal == (Participants.Count() * 2) )
            {
                Driverschanged?.Invoke(this, new DriversChangedEventArgs(Track));
                return true;
               

            }
            return false;
        }


        public void clear()
        {
            Thread.Sleep(1000);
            Driverschanged = null;
            timer.Stop();
            
        }

        private lParticipant DriversFinishedLeft(lParticipant? participant)
        {
            

            if (participant != null)
            {
                if (!(laps.ContainsKey(participant))){
                    laps.Add(participant, 1);
                    return participant;
                } else 
                {
                    laps[participant] += 1;
                    if (laps[participant] >= 2)
                    {
                        return null;
                    }
                    else
                    {
                        return participant;
                    }

                }
                
                
            }


            return participant;
            
          

        }

        
        

        public void LeftDriversMove(Section section)
        {
            int participantspeed = GetSectionData(section).Left.Equipment.Speed;
            int participantperformance = GetSectionData(section).Left.Equipment.Performance;
            int aftandperhalveseconde = participantspeed * participantperformance;
            Section volgendesection = Track.NextSection(section);
            



            

            // als de sectie uitgereden is moet de rijder door naar de volgende sectie en moet de distance gereset worden naar 40
            if (GetSectionData(section).DistanceLeft <= 0 )
            {

                //volgendesection = Track.NextSection(section);

                if (GetSectionData(volgendesection).Left == null && GetSectionData(section).Left.Equipment.isBroken == false)
                    {
                        GetSectionData(volgendesection).Left = GetSectionData(section).Left;
                        GetSectionData(volgendesection).DistanceLeft = GetSectionData(section).DistanceLeft + 40;
                        GetSectionData(section).Left = null;
                        GetSectionData(section).DistanceLeft = 40;

                    }else if (GetSectionData(volgendesection).Right == null && GetSectionData(section).Left.Equipment.isBroken == false)
                    {
                        GetSectionData(volgendesection).Right = GetSectionData(section).Left;
                        GetSectionData(volgendesection).DistanceRight = GetSectionData(section).DistanceLeft + 40;
                        GetSectionData(section).Left = null;
                        GetSectionData(section).DistanceLeft = 40;

                    }


            }
            else
            {
                GetSectionData(section).DistanceLeft = GetSectionData(section).DistanceLeft - aftandperhalveseconde;

            }




        }

        public void RightDriversMove(Section section)
        {

            int participantspeed = GetSectionData(section).Right.Equipment.Speed;
            int participantperformance = GetSectionData(section).Right.Equipment.Performance;
            int aftandperhalveseconde = participantspeed * participantperformance;
            Section volgendesection = Track.NextSection(section);


            

            if (GetSectionData(section).DistanceRight <= 0 )
            {
                
                    
                    if (GetSectionData(volgendesection).Right == null && GetSectionData(section).Right.Equipment.isBroken == false)
                    {
                        GetSectionData(volgendesection).Right = GetSectionData(section).Right;
                        GetSectionData(volgendesection).DistanceRight = GetSectionData(section).DistanceRight + 40;
                        GetSectionData(section).Right = null;
                        GetSectionData(section).DistanceRight = 40;
                    } 
                    else if (GetSectionData(volgendesection).Left == null && GetSectionData(section).Right.Equipment.isBroken == false)
                    {
                        GetSectionData(volgendesection).Left = GetSectionData(section).Right;
                        GetSectionData(volgendesection).DistanceLeft = GetSectionData(section).DistanceRight + 40;
                        GetSectionData(section).Right = null;
                        GetSectionData(section).DistanceRight = 40;
                    }

                

            }
            else
            {
                GetSectionData(section).DistanceRight = GetSectionData(section).DistanceRight - aftandperhalveseconde;
            }
           

        }

    }

}
