﻿using Controller;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
using System.Windows.Media.Imaging;
using System.Net.Http.Headers;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Security.Cryptography.X509Certificates;

namespace WpfApp1
{
    public static class VisualizeWPF
    {
        // basic path
        private const string Path = "C:\\Users\\Gebruiker\\source\\repos\\Formule\\WpfApp1\\Images\\";

        // sections
        private const string start1 = Path + "start1.png";
        private const string start2 = Path + "startfoto2.png";
        private const string start3 = Path + "startfoto.png";
        private const string finishsectie = Path + "finishsectie.png";
        private const string leftcornereast = Path + "leftcornereast.png";
        private const string leftcornernorth = Path + "leftcornernorth.png";
        private const string leftcornersouth = Path + "LeftcornerSouth.png";
        private const string leftcornerwest = Path + "leftcornerwest.png";
        private const string rightcornereast = Path + "rightcornereast.png";
        private const string rightcornernorth = Path + "RightcornerNorth.png";
        private const string rightcornersouth = Path + "rightcornersouth.png";
        private const string rightcornerwest = Path + "rightcornerwest.png";
        private const string straighthorzontaleast = Path + "Straighthorizontaleast.png";
        private const string straighthorzontalwest = Path + "Straighthorizontalwest.png";
        private const string straightverticalnorth = Path + "straightverticalnorth.png";
        private const string straightverticalsouth = Path + "straightverticalsouth.png";

        // cars
        private const string racecarblauw = Path + "Racecarblauw.png";
        private const string racecargeel = Path + "Racecargeel.png";
        private const string racecargroen = Path + "Racecargroen.png";
        private const string racecaroranje = Path + "Racecaroranje.png";
        private const string racecarpaars = Path + "RacecarPaars.png";
        private const string racecarrood = Path + "Racecarrood.png";

        // x and y drawsection method
        static int x = 1000;
        static int y = 1000;
        static int xleftcar = 0;
        static int yleftcar = 0;
        static int xrightcar = 0;
        static int yrightcar = 0;



        public static BitmapSource DrawTrack(Track track)
        {


            Bitmap Bitmap = AanmakenAfbeelding.ImageCreate(2500, 2000);
            Graphics Graphics = Graphics.FromImage(Bitmap);


            foreach (Section sectie in track.Sections)
            {
                Drawsection(sectie, sectie.SectionType, Graphics);
                
            }

            return AanmakenAfbeelding.CreateBitmapSourceFromGdiBitmap(Bitmap);

        }

        // per sectie checken op naam links en rechts en een auto returnen in bitmap vorm
        public static Bitmap Returncars(lParticipant driver)
        {
            Bitmap? Car;
            if (driver != null)
            {

                string drivernow = driver.Name[driver.Name.Length - 1].ToString();
                #region driver check
                switch (drivernow)
                {
                    case "1":
                        Car = new Bitmap(racecarblauw);
                        break;
                    case "2":
                        Car = new Bitmap(racecargeel);
                        break;
                    case "3":
                        Car = new Bitmap(racecargroen);
                        break;
                    case "4":
                        Car = new Bitmap(racecarpaars);
                        break;
                    case "5":
                        Car = new Bitmap(racecaroranje);
                        break;
                    case "6":
                        Car = new Bitmap(racecarrood);
                        break;

                    default:
                        return null;
                        #endregion
                }
                return Car;
            } else
            {
                return null;
            }
        }
        // returns left participant of the section
        public static lParticipant ReturnLeftParticipant(Section sectie)
        {

            return Data.CurrentRace.GetSectionData(sectie).Left;
        }
        //returns right participant of the section
        public static lParticipant ReturnRightParticipant(Section sectie)
        {
            return Data.CurrentRace.GetSectionData(sectie).Right;
        }

        // draws the left car of the section if there is a left pariticipant
        public static void DrawLeftCar(Section sectie, Graphics graphics)
        {
            lParticipant links = ReturnLeftParticipant(sectie);
            Bitmap auto = Returncars(links);
            rotatee(sectie, auto);
            
            if (auto != null)
            {
                XAndYLeftCar(sectie);
                graphics.DrawImage(auto, xleftcar, yleftcar);
            }
        }
        public static void XAndYRightCar(Section sectie)
        {
            switch (sectie.SectionType)
            {
                #region start checks
                case SectionTypes.StartGrid:
                    xrightcar = x + 12;
                    yrightcar = y + 65;
                    break;
                case SectionTypes.StartGrid3:
                    xrightcar = x + 12;
                    yrightcar = y + 65;
                    break;
                case SectionTypes.StartGrid2:
                    xrightcar = x + 12;
                    yrightcar = y + 65;
                    break;

                #endregion

                #region rightcornerchecks
                case SectionTypes.RightCornerWest:
                    xrightcar = x + 15;
                    yrightcar = y + 55;
                    break;
                case SectionTypes.RightCornerEast:
                    xrightcar = x + 70;
                    yrightcar = y;
                    break;
                case SectionTypes.RightCornerSouth:
                    
                    break;
                case SectionTypes.RightCornerNorth:
                    xrightcar = x;
                    yrightcar = y + 20;
                    break;

                #endregion
                #region leftcorner checks
                case SectionTypes.LeftCornerNorth:
                    xrightcar = x + 25;
                    yrightcar = y;

                    break;
                case SectionTypes.LeftCornerWest:
                    xrightcar = x + 60;
                    yrightcar = y + 25;

                    break;
                case SectionTypes.LeftCornerSouth:
                    xrightcar = x + 25;
                    yrightcar = y + 20;
                    break;
                case SectionTypes.LeftCornerEast:
                    xrightcar = x + 20;
                    yrightcar = y + 25;
                    break;
                #endregion
                #region straight checks
                case SectionTypes.StraightHorizontalWest:
                    xrightcar = x + 55;
                    yrightcar = y + 70;
                    break;
                case SectionTypes.StraightHorizontalEast:
                    xrightcar = x + 30;
                    yrightcar = y + 20;
                    break;

                case SectionTypes.StraightVerticalSouth:
                    xrightcar = x + 70;
                    yrightcar = y;
                    break;
                case SectionTypes.StraightVerticalNorth:
                    xrightcar = x + 20;
                    yrightcar = y;
                    break;
                #endregion
                #region finish checks
                case SectionTypes.Finish:
                    xrightcar = x;
                    yrightcar = y + 65;
                    break;
                default:
                    return;
                    #endregion
            }

        }
        public static void XAndYLeftCar(Section sectie)
        {
            switch (sectie.SectionType)
            {
                #region start checks
                case SectionTypes.StartGrid:
                    xleftcar = x + 12;
                    yleftcar = y + 23;
                    break;
                case SectionTypes.StartGrid3:
                    xleftcar = x + 12;
                    yleftcar = y + 23;
                    break;
                case SectionTypes.StartGrid2:
                    xleftcar = x + 12;
                    yleftcar = y + 23;
                    break;

                #endregion

                #region rightcornerchecks
                case SectionTypes.RightCornerWest:
                    xleftcar = x + 67;
                    yleftcar = y + 30;
                    break;
                case SectionTypes.RightCornerEast:
                    xleftcar = x + 20;
                    yleftcar = y + 20;
                    break;
                case SectionTypes.RightCornerSouth:

                    break;
                case SectionTypes.RightCornerNorth:
                    xleftcar = x + 26;
                    yleftcar = y + 67;

                    break;

                #endregion
                #region leftcorner checks
                case SectionTypes.LeftCornerNorth:
                    xleftcar = x + 65;
                    yleftcar = y;
                    break;
                case SectionTypes.LeftCornerWest:
                    xleftcar = x + 15;
                    yleftcar = y;
                    break;
                case SectionTypes.LeftCornerSouth:
                    xleftcar = x;
                    yleftcar = y + 65;
                    break;
                case SectionTypes.LeftCornerEast:
                    xleftcar = x + 70;
                    yleftcar = y + 50;
                    break;
                #endregion
                #region straight checks
                case SectionTypes.StraightHorizontalWest:
                    xleftcar = x + 45;
                    yleftcar = y + 20;
                    break;
                case SectionTypes.StraightHorizontalEast:
                    xleftcar = x;
                    yleftcar = y + 70;
                    break;

                case SectionTypes.StraightVerticalSouth:
                    xleftcar = x + 15;
                    yleftcar = y + 25;
                    break;
                case SectionTypes.StraightVerticalNorth:
                    xleftcar = x + 70;
                    yleftcar = y + 45;
                    break;
                #endregion
                #region finish checks
                case SectionTypes.Finish:
                    xleftcar = x;
                    yleftcar = y + 20;
                    break;
                default:
                    return;
                    #endregion
            }

        }


        // draws the right car of the section if there is a left pariticipant
        public static void DrawRightCar(Section sectie, Graphics graphics)
        {
            lParticipant rechts = ReturnRightParticipant(sectie);
            
            Bitmap auto = Returncars(rechts);
            rotatee(sectie, auto);
            if (auto != null)
            {
                XAndYRightCar(sectie);
                graphics.DrawImage(auto, xrightcar, yrightcar);
            }
        }
        // rotates car if necessescary
        public static void rotatee(Section sectie, Bitmap auto)
        {
            if (auto != null)
            {
                switch (sectie.SectionType)
                {
                    #region rightcornerchecks
                    case SectionTypes.RightCornerWest:
                        auto.RotateFlip(RotateFlipType.Rotate90FlipNone);
                        break;
                    case SectionTypes.RightCornerEast:
                        auto.RotateFlip(RotateFlipType.Rotate270FlipNone);
                        break;
                    case SectionTypes.RightCornerNorth:
                        auto.RotateFlip(RotateFlipType.Rotate180FlipNone);
                        break;

                    #endregion
                    #region leftcorner checks
                    case SectionTypes.LeftCornerNorth:
                        auto.RotateFlip(RotateFlipType.Rotate90FlipNone);
                        break;
                    case SectionTypes.LeftCornerWest:
                        auto.RotateFlip(RotateFlipType.Rotate270FlipNone);
                        break;
                    case SectionTypes.LeftCornerSouth:
                        auto.RotateFlip(RotateFlipType.Rotate180FlipNone);
                        break;
                    case SectionTypes.LeftCornerEast:
                        auto.RotateFlip(RotateFlipType.Rotate90FlipNone);
                        break;
                    #endregion
                    #region straight checks

                    case SectionTypes.StraightHorizontalEast:
                        auto.RotateFlip(RotateFlipType.Rotate180FlipNone);
                        break;

                    case SectionTypes.StraightVerticalSouth:
                        auto.RotateFlip(RotateFlipType.Rotate270FlipNone);
                        break;
                    case SectionTypes.StraightVerticalNorth:
                        auto.RotateFlip(RotateFlipType.Rotate90FlipNone);
                        break;
                    #endregion
                    #region finish checks

                    default:
                        return;
                        #endregion
                }
            }
        }

       

        

        // drawing sections
        public static void Drawsection (Section sectiee, SectionTypes sectiontype, Graphics graphics)
        {
            Bitmap sectie;
            switch (sectiontype)
            {
                #region drawing starts
                case SectionTypes.StartGrid:
                    sectie = new Bitmap(start1);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);

                    x += 125;
                    break;
                case SectionTypes.StartGrid3:
                    sectie = new Bitmap(start2);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x += 125;
                    break;
                case SectionTypes.StartGrid2:
                    sectie = new Bitmap(start3);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x += 125;
                    break;

                #endregion

                #region rightcorner drawings
                case SectionTypes.RightCornerWest:
                    sectie = new Bitmap(rightcornerwest);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y += 125;
                    break;
                case SectionTypes.RightCornerEast:
                    sectie = new Bitmap(rightcornereast);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y -= 125;
                    break;
                case SectionTypes.RightCornerSouth:
                    sectie = new Bitmap(rightcornersouth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x += 125;
                    break;
                case SectionTypes.RightCornerNorth:
                    sectie = new Bitmap(rightcornernorth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x -= 125;
                    break;

                #endregion
                #region leftcorner drawings
                case SectionTypes.LeftCornerNorth:
                    sectie = new Bitmap(leftcornernorth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x += 125;
                    break;
                case SectionTypes.LeftCornerWest:
                    sectie = new Bitmap(leftcornerwest);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y -= 125;
                    break;
                case SectionTypes.LeftCornerSouth:
                    sectie = new Bitmap(leftcornersouth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x -= 125;
                    break;
                case SectionTypes.LeftCornerEast:
                    sectie = new Bitmap(leftcornereast);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y += 125;
                    break;
                #endregion
                #region straight drawings
                case SectionTypes.StraightHorizontalWest:
                    sectie = new Bitmap(straighthorzontalwest);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x += 125;
                    break;
                case SectionTypes.StraightHorizontalEast:
                    sectie = new Bitmap(straighthorzontaleast);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x -= 125;
                    break;

                case SectionTypes.StraightVerticalSouth:
                    sectie = new Bitmap(straightverticalsouth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y -= 125;
                    break;
                case SectionTypes.StraightVerticalNorth:
                    sectie = new Bitmap(straightverticalnorth);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    y += 125;
                    break;
                #endregion
                #region finish drawing
                case SectionTypes.Finish:
                    sectie = new Bitmap(finishsectie);
                    graphics.DrawImage(sectie, x, y);
                    DrawLeftCar(sectiee, graphics);
                    DrawRightCar(sectiee, graphics);
                    x = 1000;
                    y = 1000;
                    break;
                default:
                    return;
                    #endregion
            }
        }


        public static void Initialisatie(Race R)
        {
            Data.CurrentRace.Start();
            R.Driverschanged += DriverChangend;
            R.RaceAfgelopen += Raceveranderd;
        }

        private static void Raceveranderd()
        {
            if (Data.CurrentRace != null)
            {
                Initialisatie(Data.CurrentRace);

                DrawTrack(Data.CurrentRace.Track);
            }
        }

        private static void DriverChangend(object? sender, DriversChangedEventArgs e)
        {
            DrawTrack(e.Track);

        }
    }
}
