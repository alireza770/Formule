﻿namespace Controller
{
    public static class Class1
    {

    }
}