﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Driver : lParticipant
    {

        public string Name { get; set; }
        public int Points { get; set; }
        public lEquipment Equipment { get; set; }
        public TeamColors TeamColor { get; set; }

        public Driver(string name, int points, lEquipment equipment, TeamColors teamColor)
        {
            Name = name;
            Points = points;
            Equipment = equipment;
            TeamColor = teamColor;
        }
    }
}
