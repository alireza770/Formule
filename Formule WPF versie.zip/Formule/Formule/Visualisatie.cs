﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;


namespace Formule
{
    static class Visualisatie
    {
        static int x = 50;
        static int y = 30;
        
        


        #region graphics

        #region Finish
        private static string[] Finish = {
            "______",
            "   L *",
            " R   *",
            "______",
        };
        #endregion
        #region Start
        private static string[] Start = {
            "______",
            "L     ",
            "R     ",
            "______",

        };

        private static string[] Start3 = {
            "______",
            "L     ",
            "R     ",
            "______",

        };

        private static string[] Start2 = {

            "______",
            "L     ",
            "R     ",
            "______",
        };


        #endregion
        #region corners
        private static string[] LeftcornerSouth = {
            "______",
            " L   |",
            "    R|",
            "     |",


        };
        private static string[] LeftcornerEast = {
            "______",
            "|R    ",
            "|   L ",
            "|     ",


        };
        private static string[] LeftcornerNorth = {
            "|    |",
            "|R    ",
            "|   L ",
            "|_____",
        };
        private static string[] LeftcornerWest = {
            "|    |",
            " L   |",
            "    R|",
            "_____|",
        };
        private static string[] RightcornerWest = {
            "______",
            " L   |",
            "    R|",
            "|    |"


        };
        private static string[] RightcornerSouth = {
            "______",
            "|R    ",
            "|   L ",
            "|    |",


        };
        private static string[] RightcornerEast = {
            "|    |",
            "|R    ",
            "|   L ",
            "|_____",
        };
        private static string[] RightcornerNorth = {
            "|    |",
            " L   |",
            "    R|",
            "_____|",
        };
        #endregion
        #region Straight

        private static string[] StraighthorizontalEast = {
            "______",
            "   L  ",
            " R    ",
            "______",

        };
        private static string[] StraighthorizontalWest = {
            "______",
            " R    ",
            "   L  ",
            "______",

        };

        private static string[] StraightverticalSouth = {
            "|    |",
            "|L   |",
            "|   R|",
            "|    |",

        };
        private static string[] StraightverticalNorth = {
            "|    |",
            "|R   |",
            "|   L|",
            "|    |",

        };

        #endregion

        #endregion

        public static void DriverschangedEventhandler(object? obj,DriversChangedEventArgs driverschanged)
        {
            Drawtrack(driverschanged.Track);
        }
        public static void Raceveranderd()
        {
          if (Data.CurrentRace != null)
            {
                Initalize(Data.CurrentRace);

                Drawtrack(Data.CurrentRace.Track);
            }
            
           
        }


        public static void Initalize(Race race)
        {
            Console.Clear();
            Data.CurrentRace.Start();
            race.Driverschanged += DriverschangedEventhandler;
            race.RaceAfgelopen += Raceveranderd;
        }

       
        public static void Drawsectie(Section sec)
        {
            #region checks
            lParticipant left = Data.CurrentRace.GetSectionData(sec).Left; 
            lParticipant right = Data.CurrentRace.GetSectionData(sec).Right; 
            string sectie = sec.SectionType.ToString();
            switch (sectie)
            {
                
                case "StartGrid":

                    
                    
                    for (int i = 0; i < Start.Length; i++)
                        {

                        string a = Start[i];
                        a = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                            y += 1;
                        }
                        y -= 4;
                        x += 6;
                    break;

                case "StartGrid3":


                 

                    for (int i = 0; i < Start3.Length; i++)
                    {
                        string a = Start3[i];
                             a = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x += 6;
                    break;

                case "StartGrid2":


                    for (int i = 0; i < Start2.Length; i++)
                    {
                        string a = Start2[i];
                          a  = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x += 6;
                    break;

                case "StraightHorizontalWest":
                    
                    for (int i = 0; i < StraighthorizontalWest.Length; i++)
                    {
                        string a = StraighthorizontalWest[i];
                            a = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x += 6; 
                    break;

                case "StraightHorizontalEast":

                    for (int i = 0; i < StraighthorizontalEast.Length; i++)
                    {
                        string a = StraighthorizontalEast[i];
                            a = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x -= 6;
                    break;

                case "StraightVerticalNorth":

                    for (int i = 0; i < StraightverticalNorth.Length; i++)
                    {
                        string a = StraightverticalNorth[i];
                             a = VisualizeParticipants(a, left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }                   
                    break;

                case "StraightVerticalSouth":
                    for (int i = 0; i < StraightverticalSouth.Length; i++)
                    {
                        string a = StraightverticalSouth[i];
                          a  = VisualizeParticipants(StraightverticalSouth[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 8;
                    break;

                case "LeftCornerEast":

                    for (int i = 0; i < LeftcornerEast.Length; i++)
                    {
                        string a = LeftcornerEast[i];
                           a = VisualizeParticipants(LeftcornerEast[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    
                    break;


                case "LeftCornerWest":

                    for (int i = 0; i < LeftcornerWest.Length; i++)
                    {
                        string a = LeftcornerWest[i];
                            a = VisualizeParticipants(LeftcornerWest[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 8;
                    
                    break;

                case "LeftCornerNorth":

                    for (int i = 0; i < LeftcornerNorth.Length; i++)
                    {
                        string a = LeftcornerNorth[i];
                             a = VisualizeParticipants(LeftcornerNorth[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    x += 6;
                    y -= 4;
                    break;

                case "LeftCornerSouth":

                    for (int i = 0; i < LeftcornerSouth.Length; i++)
                    {
                        string a = LeftcornerSouth[i];
                           a  = VisualizeParticipants(LeftcornerSouth[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x -= 6;
                    break;

                case "RightCornerEast":

                    for (int i = 0; i < RightcornerEast.Length; i++)
                    {
                        string a = RightcornerEast[i];
                           a  = VisualizeParticipants(RightcornerEast[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    
                    y -= 8;
                    break;

                case "RightCornerWest":

                    for (int i = 0; i < RightcornerWest.Length; i++)
                    {
                        string a = RightcornerWest[i];
                         a   = VisualizeParticipants(RightcornerWest[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }

                    break;
                case "RightCornerNorth":

                    for (int i = 0; i < RightcornerNorth.Length; i++)
                    {
                        string a = RightcornerNorth[i];
                           a  = VisualizeParticipants(RightcornerNorth[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x -= 6;
                    break;
                case "RightCornerSouth":

                    for (int i = 0; i < RightcornerSouth.Length; i++)
                    {
                        string a = RightcornerSouth[i];
                            a = VisualizeParticipants(RightcornerSouth[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    y -= 4;
                    x += 6;
                    break;

                case "Finish":

                    for (int i = 0; i < Finish.Length; i++)
                    {
                        string a = Finish[i];
                           a  = VisualizeParticipants(Finish[i], left, right);
                        
                        Console.SetCursorPosition(x, y);
                        Console.WriteLine(a);
                        y += 1;
                    }
                    
                    x = 50;
                    y = 30;
                    break;



            }
            #endregion
        }


        
        public static void Drawtrack(Track track)
        {

            Console.SetWindowSize(Console.LargestWindowWidth, Console.LargestWindowHeight);
            Console.WriteLine(track.Name);


            


                foreach (var item in track.Sections)
                {

                    Section sectie = item;

                    Drawsectie(sectie);
                }
                
            
        }

    

        public static string VisualizeParticipants (string tekst, lParticipant participant1 , lParticipant participant2)
        {
            if (participant1 == null)
            {
                tekst = tekst.Replace("L", " ");
            }
            if (participant2 == null)
            {
                tekst = tekst.Replace("R", " ");
            }


            if ( participant1 != null ) {


                if (participant1.Equipment.isBroken)
                {
                    

                    tekst = tekst.Replace("L","#");
                }
                else
                {
                    char participantleft = participant1.Name[participant1.Name.Length - 1];
                    tekst = tekst.Replace("L", participantleft.ToString());
                }
                

            } 
            if (participant2 != null)
            {
                if (participant2.Equipment.isBroken)
                {

                    tekst = tekst.Replace("R", "#");
                }
                else
                {
                    char participantRight = participant2.Name[participant2.Name.Length - 1];
                    tekst = tekst.Replace("R", participantRight.ToString());
                }

            }



            return tekst;
        }

    }
}
