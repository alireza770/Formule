﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Model
{

    public class Track 
    {
        public String Name { get; set; }
        public LinkedList<Section> Sections { get; set; } = new LinkedList<Section>();

        public Track (String name, SectionTypes[] sections)
        {
            Name = name;
           Sections = omzettingsections(sections);
        }

        public LinkedList<Section> omzettingsections (SectionTypes[] sectiontypes)
        {
            LinkedList<Section> sections = new LinkedList<Section>();

            foreach (SectionTypes sec in sectiontypes)
            {
                sections.AddLast(new Section(sec));
            }
            return sections;
        }

        public Section NextSection(Section sectionnu)
        {
            LinkedListNode<Section> sectienu = Sections.Find(sectionnu);
            Section eerste = Sections.First();
            if (sectionnu != Sections.Last())
            {
                return sectienu.Next.Value;

            }
            return eerste;

        }


    }
}
