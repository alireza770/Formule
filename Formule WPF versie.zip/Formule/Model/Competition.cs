﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
   public class Competition
    {
        public List<lParticipant> Participants { get; set; } = new List<lParticipant>();    
        public Queue<Track> Tracks { get; set; } = new Queue<Track>();  

        public Track NextTrack()
        {
            
            if (Tracks.Count != 0)
            {
                return Tracks.Dequeue();
            } else
            {
                return null;
            }
            
        }

    }
}
