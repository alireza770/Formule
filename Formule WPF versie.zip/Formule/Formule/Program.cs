﻿// See https://aka.ms/new-console-template for more information
using Controller;
using Model;
using System.Diagnostics;
using static Controller.Data;

namespace Formule
{
    static class Program
    {
        static void Main(string[] args)
        {

            Initialize();


            Visualisatie.Initalize(CurrentRace);




            for (; ; )
            {
                Thread.Sleep(100);
            }

        }
    }
}



