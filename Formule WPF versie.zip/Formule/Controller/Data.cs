﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using Model;




namespace Controller
{

    public static class Data
    {
        public static Competition Competition { get; set; }
        private static int nummer = 0;
        private static int teamcolor = 0;
       
        public static Race CurrentRace { get; set; }
        

        public static void Initialize()
        {
            Competition = new Competition();
           
            

            AddParticipant();
            AddParticipant();
            AddParticipant();
            AddParticipant();
            AddParticipant();
            AddParticipant();


            AddTrack();
            
            NextRace();


        }

        public static void AddParticipant()
        {
            nummer++;
            teamcolor++;
            teamcolor = teamcolor % 4;
            Car auto = new Car (30,50,3,false);
            Driver bestuurder = new Driver("Bestuurder" + nummer,0,auto,(TeamColors)teamcolor);

            Competition.Participants.Add(bestuurder);
    }

        public static void AddTrack()
        {

            
            

            var s = SectionTypes.StartGrid;
            var s2 = SectionTypes.StartGrid2;
            var s3 = SectionTypes.StartGrid3;
            var straighthorizontalwest = SectionTypes.StraightHorizontalWest;
            var straighthorizontaleast = SectionTypes.StraightHorizontalEast;
            var straightverticalnorth = SectionTypes.StraightVerticalNorth;
            var straightverticalsouth = SectionTypes.StraightVerticalSouth;
            var rightwest =  SectionTypes.RightCornerWest;
            var righteast =  SectionTypes.RightCornerEast;
            var rightsouth = SectionTypes.RightCornerSouth;
            var rightnorth = SectionTypes.RightCornerNorth;
            var leftsouth = SectionTypes.LeftCornerSouth;
            var leftnorth = SectionTypes.LeftCornerNorth;
            var leftwest = SectionTypes.LeftCornerWest;
            var lefteast = SectionTypes.LeftCornerEast;
            var f = SectionTypes.Finish;


            SectionTypes[] Spanje = new SectionTypes[22];
            Spanje[0] = s;
            Spanje[1] = s2;
            Spanje[2] = s3;
            Spanje[3] = rightwest;
            Spanje[4] = leftnorth;
            Spanje[5] = straighthorizontalwest;
            Spanje[6] = leftwest;
            Spanje[7] = straightverticalsouth;
            Spanje[8] = straightverticalsouth;
            Spanje[9] = leftsouth;
            Spanje[10] = lefteast;
            Spanje[11] = rightnorth;
            Spanje[12] = righteast;
            Spanje[13] = leftsouth;
            Spanje[14] = straighthorizontaleast;
            Spanje[15] = lefteast;
            Spanje[16] = rightnorth;
            Spanje[17] = straighthorizontaleast;
            Spanje[18] = straighthorizontaleast;
            Spanje[19] = lefteast;
            Spanje[20] = leftnorth;
            Spanje[21] = f;


            Track Trackspanje = new Track("Spanje", Spanje);
            Competition.Tracks.Enqueue(Trackspanje);

            SectionTypes[] Engeland = new SectionTypes[18];
            Engeland[0] = s;
            Engeland[1] = s3;
            Engeland[2] = s2;
            Engeland[3] = straighthorizontalwest;
            Engeland[4] = leftwest;
            Engeland[5] = straightverticalsouth;
            Engeland[6] = straightverticalsouth;
            Engeland[7] = leftsouth;
            Engeland[8] = straighthorizontaleast;
            Engeland[9] = straighthorizontaleast;
            Engeland[10] = lefteast;
            Engeland[11] = rightnorth;
            Engeland[12] = straighthorizontaleast;
            Engeland[13] = straighthorizontaleast;
            Engeland[14] = lefteast;
            Engeland[15] = straightverticalnorth;
            Engeland[16] = leftnorth;
            Engeland[17] = f;
            Track TrackEngeland = new Track("Engeland", Engeland);

            Competition.Tracks.Enqueue(TrackEngeland);





        }
        public static void NextRace()
        {

            if (CurrentRace != null)
            {
                CurrentRace.RaceAfgelopen -= NextRace;

            }

            var track = Competition.NextTrack();
            if (track == null)
            {
                CurrentRace.clear();
                CurrentRace = null;
            }
            if (track != null)
            {
                
                CurrentRace = new Race(track, Competition.Participants);
                CurrentRace.RaceAfgelopen += NextRace;
                CurrentRace.Start();
                
                

            }
          
        }

       




    }
}
