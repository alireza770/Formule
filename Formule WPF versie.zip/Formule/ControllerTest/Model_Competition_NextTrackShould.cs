﻿using Model;
using NUnit.Framework.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControllerTest
{

    [TestFixture]
    public class Model_Competition_NextTrackShould
    {
        private Competition _competition;

        [SetUp]
        public void setup()
        {
            _competition = new Competition();
        }

        [Test]
        public void NextTrack_EmptyQueue_ReturnNull()
        {
            var result = _competition.NextTrack();
            Assert.IsNull(result);
        }

        [Test]
        public void NextTrack_OneInQueue_ReturnTrack()
        {
            var r = SectionTypes.RightCorner;
            var l = SectionTypes.LeftCorner;
            var f = SectionTypes.Finish;
            var s = SectionTypes.StartGrid;
            var sr = SectionTypes.Straight;
            SectionTypes[] Spanje = new SectionTypes[22];
            Spanje[0] = s;
            Spanje[1] = sr;
            Spanje[2] = r;
            Spanje[3] = sr;
            Spanje[4] = l;
            Spanje[5] = sr;
            Spanje[6] = sr;
            Spanje[7] = l;
            Spanje[8] = sr;
            Spanje[9] = sr;
            Spanje[10] = sr;
            Spanje[11] = l;
            Spanje[12] = sr;
            Spanje[13] = sr;
            Spanje[14] = sr;
            Spanje[15] = sr;
            Spanje[16] = sr;
            Spanje[17] = sr;
            Spanje[18] = l;
            Spanje[19] = sr;
            Spanje[20] = l;
            Spanje[21] = f;
            Track test = new Track("test",Spanje);
            _competition.Tracks.Enqueue(test);
            var result = _competition.NextTrack();
            Assert.AreEqual(test, result);
        }

        [Test]

        public void NextTrack_OneInQueue_RemoveTrackFromQueue()
        {
            var r = SectionTypes.RightCorner;
            var l = SectionTypes.LeftCorner;
            var f = SectionTypes.Finish;
            var s = SectionTypes.StartGrid;
            var sr = SectionTypes.Straight;
            SectionTypes[] Spanje = new SectionTypes[22];
            Spanje[0] = s;
            Spanje[1] = sr;
            Spanje[2] = r;
            Spanje[3] = sr;
            Spanje[4] = l;
            Spanje[5] = sr;
            Spanje[6] = sr;
            Spanje[7] = l;
            Spanje[8] = sr;
            Spanje[9] = sr;
            Spanje[10] = sr;
            Spanje[11] = l;
            Spanje[12] = sr;
            Spanje[13] = sr;
            Spanje[14] = sr;
            Spanje[15] = sr;
            Spanje[16] = sr;
            Spanje[17] = sr;
            Spanje[18] = l;
            Spanje[19] = sr;
            Spanje[20] = l;
            Spanje[21] = f;
            Track test = new Track("test", Spanje);
            _competition.Tracks.Enqueue(test);
            var result = _competition.NextTrack();
            result = _competition.NextTrack();
            Assert.Null(result);
        }

        [Test]
        public void NextTrack_TwoInQueue_ReturnNextTrack()
        {
            var r = SectionTypes.RightCorner;
            var l = SectionTypes.LeftCorner;
            var f = SectionTypes.Finish;
            var s = SectionTypes.StartGrid;
            var sr = SectionTypes.Straight;
            SectionTypes[] Spanje = new SectionTypes[22];
            Spanje[0] = s;
            Spanje[1] = sr;
            Spanje[2] = r;
            Spanje[3] = sr;
            Spanje[4] = l;
            Spanje[5] = sr;
            Spanje[6] = sr;
            Spanje[7] = l;
            Spanje[8] = sr;
            Spanje[9] = sr;
            Spanje[10] = sr;
            Spanje[11] = l;
            Spanje[12] = sr;
            Spanje[13] = sr;
            Spanje[14] = sr;
            Spanje[15] = sr;
            Spanje[16] = sr;
            Spanje[17] = sr;
            Spanje[18] = l;
            Spanje[19] = sr;
            Spanje[20] = l;
            Spanje[21] = f;
            Track test = new Track("test", Spanje);
            _competition.Tracks.Enqueue(test);

            SectionTypes[] Engeland = new SectionTypes[21];
            Engeland[0] = s;
            Engeland[1] = sr;
            Engeland[2] = l;
            Engeland[3] = sr;
            Engeland[4] = sr;
            Engeland[5] = l;
            Engeland[6] = sr;
            Engeland[7] = l;
            Engeland[8] = r;
            Engeland[9] = sr;
            Engeland[10] = l;
            Engeland[11] = sr;
            Engeland[12] = l;
            Engeland[13] = f;
            Track TrackEngeland = new Track("Engeland", Engeland);
            _competition.Tracks.Enqueue(TrackEngeland);

            _competition.Tracks.Dequeue();

            var result = _competition.NextTrack();

            Assert.AreEqual(result, TrackEngeland);


        }

    }
}
