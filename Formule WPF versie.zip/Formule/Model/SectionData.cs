﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class SectionData
    {

        public lParticipant Left { get; set; } = null;
        public int DistanceLeft { get; set; } = 40;
        public lParticipant Right { get; set; } = null;
        public int DistanceRight { get; set; } = 40;

    }
}
